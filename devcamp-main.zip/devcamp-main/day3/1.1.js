// Day_3 : Homework 1.1
function draw(n){
  text = '';
  for (let i=0; i<n; i++) {
    text += '*';
    }
  console.log(text);
}

draw(4);

  



  


